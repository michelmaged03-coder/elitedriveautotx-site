Elite Drive Auto TX — Website Template (v3)

This folder contains your ready-to-upload static website.

Your details:
- Phone: 214-315-1353
- Email: sales@elitedriveautotx.com
- Domain: https://www.elitedriveautotx.com

Deploy (Netlify - drag & drop):
1) Go to Netlify → Add new project → Start from files (aka Netlify Drop).
2) Drag & drop this entire folder.
3) Copy the *.netlify.app URL it gives you.
4) Add your custom domain in Domain Management and point GoDaddy DNS to Netlify.
